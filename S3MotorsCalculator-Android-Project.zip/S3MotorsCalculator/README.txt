S3 MOTORS Calculator - Android Studio project

Features:
- Offline Price Calculator (default profit margin 35%)
- Offline Discount Calculator (default discount 5%)
- English interface
- S3 logo used in app header and launcher icon

To build an APK:
1. Install Android Studio and Android SDK (API 35).
2. Open this project folder in Android Studio.
3. Wait for Gradle sync to finish.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in app/build/outputs/apk/debug/app-debug.apk

This ZIP contains the Android source project, not a precompiled APK.
